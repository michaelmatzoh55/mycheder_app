import os,re,time
H=os.path.dirname(os.path.abspath(__file__)); w=os.path.join(H,"sw.js")
if os.path.exists(w):
    t=open(w).read(); t=re.sub(r'const CACHE="my-cheder-\d+"','const CACHE="my-cheder-%d"'%time.time(),t); open(w,"w").write(t)
print("App updated.")
