/* ================= TEACHER MODE + GOLDEN GELT =================
   Shekels (S.gelt) are the everyday coins. Golden Gelt (S.gold) is the rare prize.
   Teacher Mode lives on the teacher's own phone or iPad, behind a PIN. Students, scores and notes stay on that device.
   A teacher can give Golden Gelt on a student's own device, or with a short code the student types in at home. */
(function(){
S.gold=S.gold||0; S.codes=S.codes||[]; S.ver=S.ver||{};
const KEY="myCheder.teacher";
let T; try{ T=JSON.parse(localStorage.getItem(KEY)||"null") }catch(e){ T=null } T=T||{pin:"",st:[]};
const tsave=()=>{ try{ localStorage.setItem(KEY,JSON.stringify(T)) }catch(e){} };
let open=false, V=null;               // unlocked this session, current screen state
const R=()=>window.READ;               // reading levels (from belts.js)
const today=()=>Math.floor(Date.now()/864e5);
const fmt=t=>new Date(t).toLocaleDateString([],{month:"short",day:"numeric",year:"numeric"});
const avg=a=>a.length?Math.round(a.reduce((x,y)=>x+y,0)/a.length*10)/10:0;
const gold=n=>`<span class="coin gold sm">✡</span><b>${n}</b>`;

/* ---------- Golden Gelt codes ---------- */
const AL="23456789ABCDEFGHJKMNPQRSTUVWXYZ";
function h32(s){ let h=2166136261; for(const c of s){ h^=c.charCodeAt(0); h=Math.imul(h,16777619) } return h>>>0 }
function enc(n,len){ let o=""; for(let i=0;i<len;i++){ o=AL[n%31]+o; n=Math.floor(n/31) } return o }
function dec(s){ let n=0; for(const c of s){ const i=AL.indexOf(c); if(i<0) return -1; n=n*31+i } return n }
// payload: amount 1-9, what (0 = prayer, 1-8 = reading level), day, random
function makeCode(amount,what){ const r=Math.floor(Math.random()*900), body=((today()%4000)*10+what)*10*1000+amount*1000+r;
  const p=enc(body,7), c=enc(h32(p+"my-cheder-gold")%961,2); return `${p.slice(0,4)}-${p.slice(4)}${c}` }
function readCode(raw){ const s=raw.toUpperCase().replace(/[^0-9A-Z]/g,""); if(s.length!==9) return null;
  const p=s.slice(0,7), c=s.slice(7); if(enc(h32(p+"my-cheder-gold")%961,2)!==c) return null;
  const body=dec(p); if(body<0) return null; const amount=Math.floor(body/1000)%10, what=Math.floor(body/10000)%10, day=Math.floor(body/100000);
  const age=(today()%4000-day+4000)%4000; if(age>30||!amount) return null; return {amount,what,id:s} }
function giveGold(n,what,why){ S.gold=(S.gold||0)+n; if(what>0&&R()){ const L=R().L[what-1]; if(L){ S.belts=S.belts||{}; S.belts[L.k]=true; S.ver[L.k]=Date.now() } }
  save(); if(typeof renderHome==="function"&&!$("home").hidden) renderHome(); party(true); try{ sfx.klezmer() }catch(e){} toast(`+${n} Golden Gelt! ${why||""}`.trim()) }

/* ---------- Screen ---------- */
VIEWS.push("tch");
$("party").insertAdjacentHTML("beforebegin",`<div class="wrap" id="tch" hidden>
  <div class="toprow"><button class="back" id="tcBack" type="button">← Home</button></div>
  <div class="phead"><div class="he" lang="he" id="tcHe">מוֹרֶה</div><h2 id="tcH">Teacher Mode</h2><p class="when" id="tcWhen"></p></div>
  <div id="tcMain" style="display:flex;flex-direction:column;gap:14px"></div>
</div>`);
document.body.insertAdjacentHTML("beforeend",`<div id="tcPrint" aria-hidden="true"></div>`);
const set=(h,w,he)=>{ $("tcH").textContent=h; $("tcWhen").textContent=w||""; $("tcHe").textContent=he||"מוֹרֶה" };
const M=html=>{ $("tcMain").innerHTML=html; toTop() };
const stu=id=>T.st.find(s=>s.id===id);
$("tcBack").onclick=()=>{ sfx.tick(); if(V&&V.back){ const b=V.back; V=null; b() } else { showOnly("home"); renderHome() } };
function go(fn,back){ V={back}; fn() }

/* --- Kid side: type a code --- */
function openCode(){ stopPlay(); showOnly("tch"); V=null; set("Golden Gelt code","Did your teacher give you a code? Type it in!","זָהָב");
  M(`<div class="buddy compact"><span class="ywrap">${yossi("cheer")}</span><div class="bubble"><span class="name">Shlomo</span>When your teacher hears you read and you pass, they can give you a <b>Golden Gelt code</b>. Type it here to collect your gold!</div></div>
   <label class="tclab">Code <input id="tcCode" type="text" autocomplete="off" autocapitalize="characters" placeholder="ABCD-EFGHJ" maxlength="12"></label>
   <button class="btn gold big" id="tcRedeem" type="button" style="align-self:center">🪙 Collect my gold</button>
   <p class="when" style="text-align:center">You have ${gold(S.gold||0)} Golden Gelt.</p>`);
  $("tcRedeem").onclick=()=>{ const c=readCode($("tcCode").value);
    if(!c){ sfx.wrong(); toast("Hmm, that code doesn't look right. Check it and try again."); return }
    if(S.codes.includes(c.id)){ toast("You already used this code!"); return }
    S.codes.push(c.id); if(S.codes.length>200) S.codes.shift();
    const L=c.what>0&&R()?R().L[c.what-1]:null;
    giveGold(c.amount,c.what,L?`${L.name} passed with your teacher!`:"Great reading!"); openCode() } }

/* --- Lock --- */
function openTeacher(){ stopPlay(); showOnly("tch"); V=null; if(open) return classList(); lock() }
function lock(){ const first=!T.pin; set("Teacher Mode",first?"Pick a 4-digit PIN so students can't grade themselves.":"Type your PIN.","מוֹרֶה");
  M(`<div class="buddy compact"><span class="ywrap">${yossi()}</span><div class="bubble"><span class="name">Shlomo</span>${first
     ?"Welcome, teacher! Teacher Mode keeps your class list, scores and notes <b>on this device only</b>. Nothing goes online."
     :"This part is for teachers and parents."}</div></div>
   <label class="tclab">${first?"New PIN":"PIN"} <input id="tcPin" type="password" inputmode="numeric" maxlength="4" autocomplete="off"></label>
   ${first?`<label class="tclab">Type it again <input id="tcPin2" type="password" inputmode="numeric" maxlength="4" autocomplete="off"></label>`:""}
   <button class="btn gold big" id="tcIn" type="button" style="align-self:center">${first?"Set PIN":"Open"}</button>`);
  $("tcIn").onclick=()=>{ const a=$("tcPin").value.trim();
    if(first){ const b=$("tcPin2").value.trim(); if(!/^\d{4}$/.test(a)){ toast("Use 4 numbers"); return } if(a!==b){ toast("The two PINs don't match"); return } T.pin=a; tsave() }
    else if(a!==T.pin){ sfx.wrong(); toast("Wrong PIN"); return }
    open=true; sfx.pop(); classList() } }

/* --- Class list --- */
function classList(){ V=null; set("My Class",T.st.length?`${T.st.length} student${T.st.length===1?"":"s"}`:"Add your students to start","כִּתָּה");
  const row=s=>{ const t=s.t[s.t.length-1], sc=s.t.filter(x=>x.sc).flatMap(x=>x.sc);
    return `<button class="lvl tcst" type="button" data-s="${s.id}"><span class="e tcav">${esc(s.n[0]||"?").toUpperCase()}</span><span><b>${esc(s.n)}</b><span>${t?`Last: ${esc(t.ttl)} · ${fmt(t.d)}`:"Not tested yet"}</span></span><span class="tcbad">${sc.length?avg(sc)+"★":""}</span></button>` };
  M(`<div class="lvls">${T.st.map(row).join("")||""}</div>
   <div class="tcadd"><input id="tcNew" type="text" placeholder="Student's name" autocomplete="off"><button class="btn gold" id="tcAdd" type="button">+ Add</button></div>
   <div class="row" style="justify-content:center;flex-wrap:wrap">${T.st.length?`<button class="btn" id="tcAllRpt" type="button">🖨 All report cards</button>`:""}<button class="btn ghost" id="tcBak" type="button">💾 Backup / move class</button></div>
   <div class="row" style="justify-content:center;flex-wrap:wrap"><button class="btn ghost" id="tcLock" type="button">🔒 Lock</button><button class="btn ghost" id="tcPinCh" type="button">Change PIN</button></div>`);
  $("tcAdd").onclick=()=>{ const n=$("tcNew").value.trim(); if(!n) return; T.st.push({id:Date.now().toString(36),n,t:[]}); tsave(); sfx.pop(); classList() };
  $("tcNew").onkeydown=e=>{ if(e.key==="Enter") $("tcAdd").click() };
  $("tcMain").querySelectorAll("[data-s]").forEach(b=>b.onclick=()=>{ sfx.pop(); go(()=>student(b.dataset.s),classList) });
  if($("tcAllRpt")) $("tcAllRpt").onclick=()=>printCards(T.st);
  $("tcBak").onclick=()=>go(backup,classList);
  $("tcLock").onclick=()=>{ open=false; showOnly("home"); renderHome(); toast("Teacher Mode locked") };
  $("tcPinCh").onclick=()=>{ T.pin=""; tsave(); open=false; lock() } }

/* --- One student --- */
function summary(s){ const sc=s.t.filter(x=>x.sc), lv=new Set(s.t.filter(x=>x.k==="l"&&x.pass).map(x=>x.id)), pr=new Set(s.t.filter(x=>x.k==="p"&&x.pass).map(x=>x.id));
  return {r:avg(sc.map(x=>x.sc[0])),p:avg(sc.map(x=>x.sc[1])),f:avg(sc.map(x=>x.sc[2])),lv,pr} }
function student(id){ const s=stu(id); if(!s) return classList(); const m=summary(s);
  set(s.n,`${s.t.length} test${s.t.length===1?"":"s"} · ${m.pr.size} prayer${m.pr.size===1?"":"s"} passed · Level ${m.lv.size} of 8`,"תַּלְמִיד");
  const next=R()?R().L.findIndex(L=>!m.lv.has(L.k)):-1;
  M(`${s.t.some(x=>x.sc)?`<div class="tcsum"><div><b>${m.r}</b><span>Reading</span></div><div><b>${m.p}</b><span>Pronunciation</span></div><div><b>${m.f}</b><span>Fluency</span></div></div>`:""}
   <div class="row" style="justify-content:center;flex-wrap:wrap"><button class="btn gold big" id="tcTP" type="button">📖 Test a prayer</button><button class="btn gold big" id="tcTL" type="button">🛣️ Test a reading level</button></div>
   ${next>=0&&R()?`<p class="when" style="text-align:center">Next reading level: <b>${esc(R().L[next].name)}</b></p>`:""}
   ${coach(s)}
   <h3 class="tch3">Test history</h3>
   <div class="tchist">${s.t.slice().reverse().map(x=>`<div class="tcrow ${x.pass?"ok":""}"><div><b>${esc(x.ttl)}</b><span>${fmt(x.d)}${x.sc?` · ${x.sc.join(" / ")}`:""}${x.pct!=null?` · ${x.pct}%`:""}${x.wpm?` · ${x.wpm} wpm`:""}</span>${x.bad&&x.bad.length?`<span class="tcbw" lang="he">Practice: ${x.bad.map(esc).join(" · ")}</span>`:""}${x.note?`<span>📝 ${esc(x.note)}</span>`:""}</div><em>${x.pass?"✓ Passed":"Not yet"}</em></div>`).join("")||`<p class="when">No tests yet.</p>`}</div>
   <div class="row" style="justify-content:center;flex-wrap:wrap"><button class="btn" id="tcRpt" type="button">🖨 Report card</button><button class="btn ghost" id="tcShare" type="button">📤 Share with parents</button><button class="btn ghost" id="tcDel" type="button">Remove student</button></div>`);
  $("tcTP").onclick=()=>go(()=>pickPrayer(id),()=>student(id));
  $("tcTL").onclick=()=>go(()=>pickLevel(id),()=>student(id));
  $("tcRpt").onclick=()=>printCards([s]);
  $("tcShare").onclick=()=>shareText(cardText(s));
  $("tcDel").onclick=()=>{ $("tcDel").textContent="Tap again to remove"; $("tcDel").onclick=()=>{ T.st=T.st.filter(x=>x!==s); tsave(); classList() } } }
function coach(s){ const bad={}; s.t.slice(-6).forEach(x=>(x.bad||[]).forEach(w=>bad[w]=(bad[w]||0)+1));
  const top=Object.entries(bad).sort((a,b)=>b[1]-a[1]).slice(0,8).map(x=>x[0]);
  const low=s.t.filter(x=>x.sc).slice(-3), m=low.length?[0,1,2].map(i=>avg(low.map(x=>x.sc[i]))):null;
  const weak=m?["reading","pronunciation","fluency"][m.indexOf(Math.min(...m))]:null;
  if(!top.length&&!weak) return "";
  return `<div class="tccoach"><b>What to practice next</b>${weak&&Math.min(...m)<4?`<span>Work on <b>${weak}</b> (lowest score lately).</span>`:""}${top.length?`<span lang="he" class="tcbw">${top.map(esc).join(" · ")}</span>`:""}</div>` }

/* --- Pick a prayer --- */
function pickPrayer(id){ const s=stu(id); set("Test a prayer",`Pick a prayer for ${s.n}`,"תְּפִלָּה");
  const seen=new Set(), groups=GROUPS.map(g=>({n:g.name,p:g.prayers.filter(p=>p&&!seen.has(p.id)&&seen.add(p.id))}));
  const bm=SIDDUR.find(g=>g.bm); if(bm) groups.push({n:"Bar Mitzvah",p:bm.prayers.filter(p=>!seen.has(p.id)&&seen.add(p.id))});
  const passed=new Set(s.t.filter(x=>x.k==="p"&&x.pass).map(x=>x.id));
  M(groups.map(g=>`<h3 class="tch3">${esc(g.n)}</h3><div class="tcgrid">${g.p.map(p=>`<button class="tcpill ${passed.has(p.id)?"ok":""}" type="button" data-p="${p.id}">${p.icon?p.icon+" ":""}${esc(p.title)}${passed.has(p.id)?" ✓":""}</button>`).join("")}</div>`).join(""));
  $("tcMain").querySelectorAll("[data-p]").forEach(b=>b.onclick=()=>{ sfx.pop(); go(()=>testPrayer(id,b.dataset.p),()=>pickPrayer(id)) }) }

/* --- Score a prayer --- */
const PICK=(k,lab)=>`<div class="tcscore"><span>${lab}</span><div>${[1,2,3,4,5].map(n=>`<button type="button" data-sc="${k}" data-n="${n}">${n}</button>`).join("")}</div></div>`;
function testPrayer(id,pid){ const s=stu(id), p=BYID[pid]; if(!p) return student(id);
  set(p.title,`${s.n} reads out loud. Tap any word that was shaky or wrong.`,p.he);
  const lines=p.lines.filter(l=>!l.head); const sc={};
  M(`<div class="pabig tcread">${lines.map((l,i)=>`<div class="tcline"><div lang="he" dir="rtl">${l.he.split(/\s+/).map((w,j)=>`<span class="tcw" data-w="${i}-${j}">${esc(w)}</span>`).join(" ")}</div><small>${esc(l.say)}</small></div>`).join("")}</div>
   <p class="when" style="text-align:center"><span id="tcBadN">0</span> word(s) marked</p>
   ${PICK(0,"Reading")}${PICK(1,"Pronunciation")}${PICK(2,"Fluency")}
   <label class="tclab">Note (optional) <textarea id="tcNote" rows="2" placeholder="Like: great kavanah, rushed the end"></textarea></label>
   <div class="row" style="justify-content:center;flex-wrap:wrap"><button class="btn gold big" id="tcPass" type="button">✓ Passed</button><button class="btn big" id="tcNot" type="button">Not yet</button></div>`);
  const total=$("tcMain").querySelectorAll(".tcw").length;
  $("tcMain").querySelectorAll(".tcw").forEach(w=>w.onclick=()=>{ w.classList.toggle("bad"); sfx.tick(); $("tcBadN").textContent=$("tcMain").querySelectorAll(".tcw.bad").length });
  $("tcMain").querySelectorAll("[data-sc]").forEach(b=>b.onclick=()=>{ sc[b.dataset.sc]=+b.dataset.n; b.parentNode.querySelectorAll("button").forEach(x=>x.classList.toggle("on",x===b)); sfx.tick() });
  const fin=pass=>{ if([0,1,2].some(k=>!sc[k])){ toast("Pick a score for all three first"); return }
    const bad=[...new Set([...$("tcMain").querySelectorAll(".tcw.bad")].map(w=>w.textContent.replace(/[,.:;]/g,"")))];
    const rec={d:Date.now(),k:"p",id:pid,ttl:p.title,sc:[sc[0],sc[1],sc[2]],bad,pct:Math.round((total-bad.length)/total*100),note:$("tcNote").value.trim(),pass};
    s.t.push(rec); tsave(); award(s,rec,pass?(avg(rec.sc)>=4.7?2:1):0,0) };
  $("tcPass").onclick=()=>fin(true); $("tcNot").onclick=()=>fin(false) }

/* --- Reading levels --- */
function pickLevel(id){ const s=stu(id); if(!R()) return student(id); const m=summary(s);
  set("Test a reading level",`Pick a level for ${s.n}`,"קְרִיאָה");
  M(`<div class="lvls">${R().L.map((L,i)=>`<button class="lvl" type="button" data-l="${i}"><span class="e tcav" style="background:${L.color};color:${L.ink}">${i+1}</span><span><b>${esc(L.name)}</b><span>${esc(L.goal)}</span></span><span class="st">${m.lv.has(L.k)?"✓":""}</span></button>`).join("")}</div>`);
  $("tcMain").querySelectorAll("[data-l]").forEach(b=>b.onclick=()=>{ sfx.pop(); go(()=>testLevel(id,+b.dataset.l),()=>pickLevel(id)) }) }
function testLevel(id,i){ const s=stu(id), L=R().L[i]; set(L.name,L.goal,"קְרִיאָה");
  if(L.kind==="speed") return speedTest(s,L,i);
  const items=L.kind==="line"?R().lineItems():L.items.slice();
  M(`<div class="bubble tcinfo">${esc(s.n)} reads each one out loud. <b>Tap the ones they got wrong.</b> Pass = 90%.</div>
   <div class="tcitems ${L.kind}">${items.map((it,j)=>`<button type="button" class="tcit" data-j="${j}"><span lang="he">${R().heOf(it,L)}</span><small>${esc(L.kind==="line"?R().lineSay(it):R().snd(it,L))}</small></button>`).join("")}</div>
   <p class="when" style="text-align:center" id="tcLv"></p>
   <label class="tclab">Note (optional) <textarea id="tcNote" rows="2"></textarea></label>
   <button class="btn gold big" id="tcSave" type="button" style="align-self:center">Save result</button>`);
  const upd=()=>{ const bad=$("tcMain").querySelectorAll(".tcit.bad").length, pct=Math.round((items.length-bad)/items.length*100);
    $("tcLv").innerHTML=`${items.length-bad} of ${items.length} right · <b>${pct}%</b> · ${pct>=90?"✓ Passing":"Not passing yet"}`; return pct };
  $("tcMain").querySelectorAll(".tcit").forEach(b=>b.onclick=()=>{ b.classList.toggle("bad"); sfx.tick(); upd() }); upd();
  $("tcSave").onclick=()=>{ const pct=upd(), pass=pct>=90, bad=[...$("tcMain").querySelectorAll(".tcit.bad span")].map(x=>x.textContent);
    const rec={d:Date.now(),k:"l",id:L.k,ttl:L.name,pct,bad,note:$("tcNote").value.trim(),pass}; s.t.push(rec); tsave(); award(s,rec,pass?2:0,i+1) } }
function speedTest(s,L,i){ const words=VEAHAVTA.map(l=>l.he).join(" "), n=words.split(" ").length; let t0=0, tick=null;
  M(`<div class="bubble tcinfo">${esc(s.n)} reads the first paragraph of Shema (${n} words). Tap <b>Start</b> when they begin and <b>Done</b> when they finish. Goal: ${R().SPEED} words a minute with 2 mistakes or fewer.</div>
   <div class="bz-hud"><span>${n} words</span><span id="tcClock">0s</span></div>
   <div class="pabig btcard"><div class="btpass" lang="he">${VEAHAVTA.map(l=>l.he).join("<br>")}</div></div>
   <button class="btn gold big" id="tcGo" type="button" style="align-self:center">▶ Start</button>`);
  $("tcGo").onclick=()=>{ if(!t0){ t0=performance.now(); $("tcGo").textContent="■ Done"; tick=setInterval(()=>{ const c=$("tcClock"); if(c) c.textContent=Math.round((performance.now()-t0)/1000)+"s"; else clearInterval(tick) },250); return }
    clearInterval(tick); const secs=(performance.now()-t0)/1000, wpm=Math.round(n/(secs/60));
    M(`<div class="gdone"><h3>${wpm} words a minute</h3><p>${Math.round(secs)} seconds</p></div>
     <label class="tclab">How many mistakes? <input id="tcMis" type="number" min="0" value="0" inputmode="numeric"></label>
     <label class="tclab">Note (optional) <textarea id="tcNote" rows="2"></textarea></label>
     <button class="btn gold big" id="tcSave" type="button" style="align-self:center">Save result</button>`);
    $("tcSave").onclick=()=>{ const mis=+$("tcMis").value||0, pass=wpm>=R().SPEED&&mis<=2;
      const rec={d:Date.now(),k:"l",id:L.k,ttl:L.name,wpm,pct:Math.max(0,Math.round((n-mis)/n*100)),note:$("tcNote").value.trim()+(mis?` (${mis} mistake${mis===1?"":"s"})`:""),pass};
      s.t.push(rec); tsave(); award(s,rec,pass?4:0,i+1) } } }

/* --- After saving: Golden Gelt --- */
function award(s,rec,amount,what){ sfx[rec.pass?"coin":"tick"]();
  if(!amount){ toast("Saved"); V={back:()=>student(s.id)}; return student(s.id) }
  set(rec.pass?"Passed! 🎉":"Saved",`${s.n} · ${rec.ttl}`,"זָהָב");
  const code=makeCode(amount,what);
  M(`<div class="gdone"><h3>${esc(s.n)} earned ${amount} Golden Gelt!</h3>
   <p>Give it right here, or give ${esc(s.n)} the code to type into My Cheder at home.</p>
   <div class="tccode">${code}</div><p class="when">Good for 30 days. Each code works once on each device.</p>
   <div class="row" style="justify-content:center;flex-wrap:wrap"><button class="btn gold" id="tcHere" type="button">🪙 This is ${esc(s.n)}'s device: give it now</button><button class="btn ghost" id="tcCp" type="button">📋 Copy code</button><button class="btn" id="tcDone" type="button">Done</button></div></div>`);
  party(true);
  $("tcHere").onclick=()=>{ const c=readCode(code); if(c&&!S.codes.includes(c.id)){ S.codes.push(c.id); giveGold(amount,what,"from your teacher!") } student(s.id) };
  $("tcCp").onclick=()=>{ try{ navigator.clipboard.writeText(code); toast("Code copied") }catch(e){ toast(code) } };
  $("tcDone").onclick=()=>student(s.id); V={back:()=>student(s.id)} }

/* --- Report cards --- */
function cardText(s){ const m=summary(s);
  return [`My Cheder report card: ${s.n}`,`Date: ${fmt(Date.now())}`,"",
    s.t.some(x=>x.sc)?`Average scores (1-5): Reading ${m.r} · Pronunciation ${m.p} · Fluency ${m.f}`:"",
    `Reading level: ${m.lv.size} of 8 passed`,`Prayers passed: ${[...m.pr].map(id=>BYID[id]?BYID[id].title:id).join(", ")||"none yet"}`,"",
    "Tests:",...s.t.map(x=>`- ${fmt(x.d)}: ${x.ttl}, ${x.pass?"passed":"not yet"}${x.sc?` (${x.sc.join("/")})`:""}${x.pct!=null?`, ${x.pct}%`:""}${x.wpm?`, ${x.wpm} wpm`:""}${x.note?`. ${x.note}`:""}`)].filter((l,i,a)=>l!==""||a[i-1]!=="").join("\n") }
function shareText(t){ if(navigator.share) navigator.share({title:"My Cheder report card",text:t}).catch(()=>{}); else { try{ navigator.clipboard.writeText(t); toast("Copied! Paste it into a text or email.") }catch(e){} } }
function printCards(list){ $("tcPrint").innerHTML=list.map(s=>{ const m=summary(s);
    return `<section class="tcpc"><h1>My Cheder · Report Card</h1><h2>${esc(s.n)}</h2><p>${fmt(Date.now())}</p>
    ${s.t.some(x=>x.sc)?`<div class="tcsum"><div><b>${m.r}</b><span>Reading</span></div><div><b>${m.p}</b><span>Pronunciation</span></div><div><b>${m.f}</b><span>Fluency</span></div></div>`:""}
    <p><b>Reading level:</b> ${m.lv.size} of 8 passed</p><p><b>Prayers passed:</b> ${[...m.pr].map(id=>esc(BYID[id]?BYID[id].title:id)).join(", ")||"none yet"}</p>
    <table><tr><th>Date</th><th>Test</th><th>Result</th><th>Notes</th></tr>${s.t.map(x=>`<tr><td>${fmt(x.d)}</td><td>${esc(x.ttl)}</td><td>${x.pass?"✓ Passed":"Not yet"}${x.sc?` · ${x.sc.join("/")}`:""}${x.pct!=null?` · ${x.pct}%`:""}${x.wpm?` · ${x.wpm} wpm`:""}</td><td>${esc(x.note||"")}${x.bad&&x.bad.length?`<br><span lang="he">${x.bad.map(esc).join(" · ")}</span>`:""}</td></tr>`).join("")}</table></section>` }).join("");
  document.body.classList.add("tcprinting"); setTimeout(()=>{ try{ window.print() }catch(e){} setTimeout(()=>document.body.classList.remove("tcprinting"),500) },100) }

/* --- Backup / move to another device --- */
function backup(){ set("Backup","Move your class to another phone or iPad","גִּבּוּי");
  M(`<p class="when">Copy this, send it to yourself, and paste it into Teacher Mode on the other device.</p>
   <textarea id="tcJson" rows="6" class="tcjson">${esc(JSON.stringify({st:T.st}))}</textarea>
   <div class="row" style="justify-content:center;flex-wrap:wrap"><button class="btn gold" id="tcCopy" type="button">📋 Copy</button><button class="btn" id="tcLoad" type="button">⬇ Load what's pasted</button></div>`);
  $("tcCopy").onclick=()=>{ try{ navigator.clipboard.writeText($("tcJson").value); toast("Copied") }catch(e){ $("tcJson").select() } };
  $("tcLoad").onclick=()=>{ try{ const d=JSON.parse($("tcJson").value); if(!Array.isArray(d.st)) throw 0; T.st=d.st; tsave(); toast("Class loaded"); classList() }catch(e){ toast("That doesn't look like a class backup") } } }

/* ---------- Home: buttons + Golden Gelt counter ---------- */
const rb=$("openRpt");
if(rb) rb.insertAdjacentHTML("afterend",`<div class="row tchome" style="justify-content:center;flex-wrap:wrap"><button class="btn ghost big" id="openCode" type="button">🪙 I have a Golden Gelt code</button><button class="btn ghost big" id="openTeach" type="button">🍎 Teacher Mode</button></div>`);
$("openCode").onclick=()=>{ sfx.pop(); openCode() }; $("openTeach").onclick=()=>{ sfx.pop(); openTeacher() };
const gst=$("geltN")&&$("geltN").closest(".stat");
if(gst){ gst.insertAdjacentHTML("afterend",`<div class="stat goldstat" role="button" tabindex="0"><span class="coin gold">✡</span><div><b id="goldN">0</b><span>golden gelt</span></div></div>`);
  const g=gst.nextElementSibling; g.onclick=()=>toast("Golden Gelt is for big wins! Save it up to build the Beis Hamikdash, coming soon.") }
const _rH=renderHome; renderHome=function(){ _rH(); const g=$("goldN"); if(g) g.textContent=S.gold||0 };
window.openTeacher=openTeacher; window.openGoldCode=openCode; window.giveGold=giveGold;

document.head.insertAdjacentHTML("beforeend",`<style>
.coin.gold{background:radial-gradient(circle at 35% 30%,#fff3c4,#f2c200 50%,#9a6a00);color:#5a3a00;box-shadow:0 0 0 2px #fff6,0 0 10px #f2c20088}
.coin.sh{background:radial-gradient(circle at 35% 30%,#ffffff,#c9ced8 55%,#7d8494);color:#2e3440;font-weight:700}
.goldstat{cursor:pointer}
.tclab{display:flex;flex-direction:column;gap:6px;font-weight:700;color:var(--muted)}
.tclab input,.tclab textarea,.tcadd input,.tcjson{font:inherit;font-size:1.1rem;padding:12px;border-radius:12px;border:2px solid var(--rule);background:var(--bg);color:var(--text)}
#tcCode{font-family:ui-monospace,monospace;letter-spacing:3px;text-transform:uppercase;text-align:center;font-size:1.4rem}
.tcadd{display:flex;gap:8px}.tcadd input{flex:1;min-width:0}
.tcav{width:44px;height:44px;border-radius:50%;display:grid;place-items:center;background:var(--gold-hi);color:#3a2604;font-weight:800;font-size:1.2rem}
.tcbad{font-weight:800;color:var(--gold)}
.tcsum{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.tcsum div{background:var(--bg);border-radius:12px;padding:10px;text-align:center}
.tcsum b{display:block;font-size:1.6rem}.tcsum span{font-size:.8rem;color:var(--muted)}
.tch3{margin:6px 0 0;font-size:1.05rem}
.tchist{display:flex;flex-direction:column;gap:8px}
.tcrow{display:flex;justify-content:space-between;gap:10px;background:var(--bg);border-radius:12px;padding:10px 12px;border-left:5px solid var(--rule)}
.tcrow.ok{border-left-color:var(--good)}.tcrow div{display:flex;flex-direction:column;gap:2px}.tcrow span{font-size:.85rem;color:var(--muted)}
.tcrow em{font-style:normal;font-weight:700;white-space:nowrap;color:var(--muted)}.tcrow.ok em{color:var(--good)}
.tcbw{font-family:var(--he);font-size:1.05rem!important;color:var(--bad)!important}
.tccoach{display:flex;flex-direction:column;gap:4px;background:var(--bg);border:2px dashed var(--gold-hi);border-radius:14px;padding:12px}
.tcgrid{display:flex;flex-wrap:wrap;gap:8px}
.tcpill{font:inherit;font-weight:700;padding:10px 14px;border-radius:999px;border:2px solid var(--rule);background:var(--bg);color:var(--text);cursor:pointer}
.tcpill.ok{border-color:var(--good);color:var(--good)}
.tcread{display:flex;flex-direction:column;gap:14px}
.tcline div{font-family:var(--he);font-size:1.9rem;line-height:1.7;text-align:right}
.tcline small{display:block;color:var(--muted);font-size:.95rem}
.tcw{cursor:pointer;border-radius:8px;padding:0 3px}.tcw.bad{background:#e9456033;color:var(--bad);text-decoration:underline wavy}
.tcscore{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}.tcscore span{font-weight:700}
.tcscore div{display:flex;gap:6px}.tcscore button{width:44px;height:44px;border-radius:12px;border:2px solid var(--rule);background:var(--bg);font:inherit;font-weight:800;font-size:1.1rem;color:var(--text);cursor:pointer}
.tcscore button.on{background:var(--gold-hi);border-color:var(--gold-hi);color:#3a2604}
.tcinfo{margin:0}
.tcitems{display:grid;grid-template-columns:repeat(auto-fill,minmax(88px,1fr));gap:8px}.tcitems.line{grid-template-columns:1fr}
.tcit{font:inherit;display:flex;flex-direction:column;align-items:center;gap:2px;padding:10px;border-radius:14px;border:2px solid var(--rule);background:var(--bg);color:var(--text);cursor:pointer}
.tcit span{font-family:var(--he);font-size:2rem;font-weight:700}.tcitems.line .tcit span{font-size:1.5rem}.tcit small{color:var(--muted)}
.tcit.bad{border-color:var(--bad);background:#e9456022}.tcit.bad span{color:var(--bad);text-decoration:line-through}
.tccode{font-family:ui-monospace,monospace;font-size:2rem;font-weight:800;letter-spacing:4px;background:var(--bg);border:3px dashed var(--gold-hi);border-radius:16px;padding:14px 18px}
.tcjson{width:100%;box-sizing:border-box;font-family:ui-monospace,monospace;font-size:.8rem}
#tcPrint{display:none}
@media print{ body.tcprinting>*:not(#tcPrint){display:none!important}
  body.tcprinting #tcPrint{display:block!important;color:#000;background:#fff}
  .tcpc{page-break-after:always;font-family:Georgia,serif}.tcpc h1{font-size:14pt;margin:0}.tcpc h2{font-size:22pt;margin:6pt 0}
  .tcpc table{width:100%;border-collapse:collapse;font-size:10pt}.tcpc td,.tcpc th{border:1px solid #999;padding:4pt;text-align:left;vertical-align:top}
  .tcpc .tcsum div{border:1px solid #999} }
</style>`);
if(location.hash==="#teacher") openTeacher();
})();
