/* ================= THE 8 DOORS: the home screen is organized by the letters of MY CHEDER =================
   Nothing is moved or deleted: every card and prayer stays where it was. This file only decides which ones
   are showing. To go back to the old long home screen, remove the <script src="doors.js"> line. */
(function(){
const home=$("home"), groups=$("groups"); if(!home||!groups) return;
const DOORS=[
 {l:"M",w:"Mitzvah", e:"✅",s:"Daily mitzvos to check off"},
 {l:"Y",w:"Yom Tov", e:"🕯️",s:"Shabbos and every holiday"},
 {l:"C",w:"Chumash", e:"📜",s:"The parsha and Chitas"},
 {l:"H",w:"Hebrew",  e:"א", s:"Alef-Beis and first words"},
 {l:"E",w:"Eating",  e:"🍎",s:"Brachos before and after food"},
 {l:"D",w:"Davening",e:"🙏",s:"Prayers with the yad"},
 {l:"E",w:"Earn",    e:"🪙",s:"Shekels, Golden Gelt and prizes"},
 {l:"R",w:"Rebbes",  e:"🔥",s:"The Sages and the Rebbes"}];
// Which door each card lives behind (by its id)
const CARD={openMitz:0, openHol:1, openChan:1, openPa:2, openChit:2, openAbc:3, openWords:3, openBlitz:4,
  openBM:5, openShop:6, openChal:6, openRpt:6, openTeach:6, openCode:6, openSages:7, openChs:7, openFacts:7};
// Prayer groups, by the first prayer in each group
function groupDoor(sec){ const t=sec.textContent;
  if(/Kiddush|Havdalah/.test(t)) return 1;                                     // Shabbos -> Yom Tov
  if(/Shehakol|Borei Nefoshos|Birkas Hamazon|Al Hamichya/.test(t)) return 4;    // food -> Eating
  return 5 }                                                                    // the rest -> Davening

/* ---------- Tag everything with its door ---------- */
function tag(){
  for(const [id,d] of Object.entries(CARD)){ const el=$(id); if(el) el.dataset.door=d }
  groups.querySelectorAll(":scope > section").forEach(s=>s.dataset.door=groupDoor(s));
  const men=home.querySelector(":scope > section.menorah"); if(men) men.dataset.door=5;
  const gd=home.querySelector(":scope > details.guide"); if(gd) gd.dataset.door=3;
  const ch=$("openChan"); if(ch) ch.classList.toggle("dr-now",!!(ch.previousElementSibling&&ch.previousElementSibling.classList.contains("buddy")));
}
tag(); new MutationObserver(tag).observe(groups,{childList:true});

/* ---------- The door grid and the door header ---------- */
const buddy=home.querySelector(":scope > .buddy")||$("genBox");
buddy.insertAdjacentHTML("afterend",`<nav class="drgrid" id="drGrid" aria-label="Sections">${DOORS.map((d,i)=>
  `<button class="drtile" type="button" data-open-door="${i}"><span class="drl">${d.l}</span><span class="dre" aria-hidden="true">${d.e}</span><b>${d.w}</b><small>${d.s}</small></button>`).join("")}</nav>
  <div class="drhead" id="drHead" hidden><button class="drback" id="drBack" type="button">← All sections</button><h2><span class="drl" id="drL"></span><span id="drW"></span></h2></div>`);

function show(d){
  if(d==null||d===""){ delete home.dataset.door } else home.dataset.door=d;
  const on=home.dataset.door!=null;
  $("drGrid").hidden=on; $("drHead").hidden=!on;
  if(on){ $("drL").textContent=DOORS[d].l; $("drW").textContent=DOORS[d].w }
}
function openDoor(d){ try{ sfx.pop() }catch(e){} show(d); const h=$("drHead"); window.scrollTo({top:Math.max(0,h.getBoundingClientRect().top+scrollY-130),behavior:"smooth"}) }
window.openDoor=openDoor;
$("drGrid").onclick=e=>{ const t=e.target.closest("[data-open-door]"); if(t) openDoor(+t.dataset.openDoor) };
$("drBack").onclick=()=>{ try{ sfx.pop() }catch(e){} show(null); $("drGrid").scrollIntoView({block:"center",behavior:"smooth"}) };
show(null);

/* ---------- The MY CHEDER letters at the top open the same doors ---------- */
const acro=home.querySelectorAll(".acro span");
acro.forEach((s,i)=>{ if(!DOORS[i]) return; s.setAttribute("aria-label",DOORS[i].w);
  s.onclick=()=>{ s.classList.remove("tapd"); void s.offsetWidth; s.classList.add("tapd"); setTimeout(()=>openDoor(i),140) } });

/* ---------- The "Prayers" tab at the top opens Davening ---------- */
document.querySelectorAll('[data-nav="home"]').forEach(b=>b.addEventListener("click",()=>setTimeout(()=>show(5),0)));

/* ---------- "Start Modeh Ani" and other jumps into Davening still work ---------- */
const hGo=$("hGo"); if(hGo) hGo.addEventListener("click",()=>{ if(home.dataset.door==null||home.dataset.door!=="5") show(5) },true);

document.head.insertAdjacentHTML("beforeend",`<style>
/* Grid view: hide every card and prayer group; the "happening now" Chanukah card stays as a shortcut */
#home:not([data-door]) > [data-door]:not(.dr-now), #home:not([data-door]) > #groups, #home:not([data-door]) > details.guide{display:none!important}
/* Door view: show only what lives behind this door */
${DOORS.map((_,i)=>`#home[data-door="${i}"] > [data-door]:not([data-door="${i}"]),#home[data-door="${i}"] #groups > section[data-door]:not([data-door="${i}"]){display:none!important}`).join("\n")}
#home[data-door] > #genBox, #home[data-door] > .buddy{display:none!important}
#home[data-door]:not([data-door="1"]):not([data-door="4"]):not([data-door="5"]) > #groups{display:none!important}
.drgrid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:6px 0 4px}
.drtile{position:relative;display:flex;flex-direction:column;align-items:flex-start;gap:2px;min-height:118px;padding:14px 14px 12px;border:0;border-radius:20px;text-align:left;cursor:pointer;
  background:radial-gradient(120% 90% at 85% 0%,rgba(255,226,140,.22),transparent 55%),linear-gradient(160deg,#2f5fc4,#16357f);color:#f6eedb;
  box-shadow:inset 0 0 0 2px rgba(242,198,94,.75),0 5px 0 #0d2258,0 10px 18px rgba(10,25,70,.25);-webkit-tap-highlight-color:transparent;transition:transform .12s}
.drtile:active{transform:translateY(3px);box-shadow:inset 0 0 0 2px rgba(242,198,94,.75),0 2px 0 #0d2258}
.drtile b{font-family:var(--display);font-size:1.18rem;letter-spacing:.01em}
.drtile small{font-family:var(--text);font-size:.82rem;line-height:1.25;opacity:.85}
.drtile .dre{position:absolute;right:12px;top:10px;font-size:1.5rem;font-family:var(--heb,inherit)}
.drl{font-family:var(--display);font-size:2.1rem;line-height:1;font-weight:700;background:linear-gradient(180deg,#fff4c8,#f5cf6b 50%,#c8902a);-webkit-background-clip:text;background-clip:text;color:transparent;filter:drop-shadow(0 1px 0 rgba(0,0,0,.35))}
.drhead{display:flex;flex-direction:column;align-items:flex-start;gap:6px;margin:6px 0 2px}
.drhead h2{display:flex;align-items:baseline;gap:10px;margin:0;font-family:var(--display);font-size:1.6rem}
.drhead .drl{font-size:2.4rem}
.drback{border:0;background:none;color:inherit;font:700 1rem var(--text);padding:6px 2px;cursor:pointer;opacity:.85}
</style>`);
})();
